# Design Basis

## Governing Documents
- Code_1500

## Requirements and Decisions
- Zoning: All zones are checked on a 6 ft by 6 ft grid.
- Deck G' is 1500 psf.
- Drift analysis is performed for horizontal and vertical directions.