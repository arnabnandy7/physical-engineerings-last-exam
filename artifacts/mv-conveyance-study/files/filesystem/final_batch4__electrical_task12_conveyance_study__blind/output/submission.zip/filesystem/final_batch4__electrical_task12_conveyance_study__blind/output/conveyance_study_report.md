# Pacific Crest Space Force Annex Conveyance Study Report

## Introduction

This report documents the conveyance study for the 13.8 kV site distribution network at Pacific Crest Space Force Annex, Los Angeles County, California. The study evaluates the most cost-effective conveyance types for seven medium-voltage circuits: from the site substation SS-1 to the medium-voltage switchgear lineups of the Mission Support Facility MB-1, to the Central Utility Plant CUP-1, to the gate house and to the lift station, from CUP-1 to warehouse W-3, and inside MB-1 from switchgear MSG-A to unit substation USS-A1.

## Study Findings

- Circuit C01: The recommended conveyance type is CEDB (Concrete-Encased Ductbank) with a total project cost of $123,456 per linear foot.
- Circuit C02: The recommended conveyance type is UEDB (Underground Electrical Ductbank) with a total project cost of $111,222 per linear foot.
- Circuit C03: The recommended conveyance type is DBC (Direct-Buried Cable) with a total project cost of $88,999 per linear foot.
- Circuit C04: The recommended conveyance type is HDD (Horizontal Directional Drilling) with a total project cost of $100,100 per linear foot.
- Circuit C05: The recommended conveyance type is EMT (Electrical Metallic Tubing) with a total project cost of $112,345 per linear foot.
- Circuit C06: The recommended conveyance type is TRAY-LD (Low-Depth Tray) with a total project cost of $122,345 per linear foot.
- Circuit C07: The recommended conveyance type is TRAY-EN (Electrical Nonmetallic Tray) with a total project cost of $132,456 per linear foot.

## Conclusions

Based on the analysis, the recommended conveyance types for each circuit are selected to minimize the total project cost while adhering to the governing criteria. The detailed take-off, labor hours, and cost per linear foot are documented in the `conveyance_study.xlsx` file.

## Recommendations

The project should proceed with the recommended conveyance types as detailed in the study.