# Basis for Electrical Takeoff

- Each device is counted based on the conditions specified in the project criteria and the drawings.
- Any unresolved symbols are listed in the basis document.
- The conditions are split based on the hatching and the nearest wall for each device type.
- The purchase and carton requirements are based on the project specifications and the owner's spare stock.